#include "mbed.h"

DigitalOut myled(LED1);
AnalogIn pin(PTB0);
float value,sum,average,calib;
int count;
float sample;
Timer t,t1;
DigitalOut Rojo(LED1);
DigitalOut Verde(LED2);
DigitalOut Azul(LED3);

float calibracion(){
    t.start();
    t1.start();
    float peakToPeak=0, signalMax=0, signalMin=1024;

    while (t1.read()<1) {
        while (t.read_ms()<50) {
            sample=pin.read();

            if (sample<1024) {
                if (sample>signalMax)
                    signalMax=sample;

                else if (sample<signalMin)
                    signalMin=sample;
            }
        }
     t.reset();
     peakToPeak=signalMax-signalMin;
     value= (peakToPeak*3.3);
     value = floor(value * 100) / 100;
     sum+=value;
     count++;
    }
    average=sum/count;
    t1.reset();

    return average;
    }
    
void indicate(float x , float muestra) {
    Rojo=1;
    Verde=1;
    Azul=1;
    if (muestra<x+0.03) {
            Rojo=1;
            Verde=1;
            Azul=1;
    }
    if (muestra>x+0.03&&muestra<0.5+x) {
            Rojo=1;
            Verde=0;
            Azul=1;
    }
     if (muestra>x+0.5&&muestra<1+x) {
            Rojo=1;
            Verde=0;
            Azul=0;
    }
    if (muestra>1+x&&muestra<1.4+x) {
            Rojo=1;
            Verde=1;
            Azul=0;
    }
    if (muestra>1.4+x&&muestra<1.75+x) {
            Rojo=0;
            Verde=1;
            Azul=0;
    }
    if (muestra>1.75+x&&muestra<2.8+x) {
            Rojo=0;
            Verde=1;
            Azul=1;

    }
}


float medirSonido(){
    t.start();
    float peakToPeak=0, signalMax=0, signalMin=1024;

    while (t.read_ms()<20) {
        sample=pin.read();

        if (sample<1024) {
            if (sample>signalMax)
                signalMax=sample;

            else if (sample<signalMin)
                signalMin=sample;
        }
    }
    t.reset();
    peakToPeak=signalMax-signalMin;
    value= (peakToPeak*3.3);
    value = floor(value * 100) / 100;
    sum+=value;
    count++;

    return value;
    }

int main() {
    calib=calibracion();
    while(1) {
        indicate(calib,medirSonido());
        
    }
}
